Channels = {
    CONTAINER_LOCK: 'container_lock',
    CONTAINER_MOVE: 'container_move',
    CONTAINER_RESIZE: 'container_resize',
    GUIDE_MOVE: 'guide_move',
    HANDLE_MOVE: 'handle_move',
}
